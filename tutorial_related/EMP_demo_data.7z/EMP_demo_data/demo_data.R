library(EasyMultiProfiler)
options(timeout = 600) 

## Load meta data
meta_data <- read.table('coldata.txt',header = T,row.names = 1) # row.names = 1 is necessary!

## Load dfmap
dfmap <-read.table('dfmap.txt',header = T) |> 
  dplyr::mutate(assay = factor(assay))

## Load omics data
tax_data <- EMP_taxonomy_import('tax.txt')

ko_data <- EMP_function_import('ko.txt',type = 'ko') # Processing time may vary depending on network conditions.

ec_data <- EMP_function_import('ec.txt',type = 'ec') # Processing time may vary depending on network conditions.

metbol_data <- EMP_normal_import('metabol.txt',dfmap = dfmap,assay  = 'untarget_metabol')

geno_data <- EMP_normal_import('tran.txt',dfmap = dfmap,assay  = 'host_gene')


## Combine the data into list
objlist <- list("taxonomy" = tax_data,
                "geno_ko" = ko_data,
                "geno_ec" = ec_data,
                "untarget_metabol" = metbol_data,
                "host_gene" = geno_data
)

## Create MAE object
MAE <- MultiAssayExperiment::MultiAssayExperiment(objlist, meta_data, dfmap)

## Save to file for future use without re-assembly
saveRDS(object = MAE,file = 'demo_data.rds')

## Load the saved data directly next time
MAE <- readRDS('demo_data.rds')






